def is_it_prime(n):
    #TODO: Write your code here.
