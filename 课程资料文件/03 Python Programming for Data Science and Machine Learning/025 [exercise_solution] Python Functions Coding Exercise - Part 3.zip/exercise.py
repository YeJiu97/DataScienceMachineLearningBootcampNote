def concatenate_lists(first_list, second_list):
    
    result = first_list + second_list
    
    
    return result