
def test(a, b):
    
    c = a
    a = b
    b = c

    return (a, b)