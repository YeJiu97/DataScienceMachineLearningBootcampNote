tracker = 0

def moveForwards():
    global tracker 
    tracker += 1
    print('moved forward by one step.')

def turnRight():
    global tracker
    tracker -= 1
    print('turning right')
    
def move():

    #Delete this line and replace with your code. 

    return tracker
    

    
    