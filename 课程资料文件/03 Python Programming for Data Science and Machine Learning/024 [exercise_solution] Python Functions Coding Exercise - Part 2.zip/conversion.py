# Solution File

def calc_square_meters_from_feet(length_ft, width_ft):
    
    metric_length = length_ft * 0.3048
    metric_width = width_ft * 0.3048
    metric_area = metric_length * metric_width
    
    return metric_area
