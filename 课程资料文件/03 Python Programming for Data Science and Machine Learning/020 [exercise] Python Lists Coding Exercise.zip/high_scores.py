def top_three(scores):
    scores = scores
    top_scores = []
    
    # TODO: Delete this line and replace with your code
    
    
    
    
    # Leave this line alone
    return top_scores
