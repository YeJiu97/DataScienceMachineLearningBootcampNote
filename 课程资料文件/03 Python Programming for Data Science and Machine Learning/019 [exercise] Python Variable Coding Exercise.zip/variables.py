
def test(A, B):
    
    a = A
    b = B
    
    # TODO: Below this comment write your code.







    # Leave this line alone as well
    return (a, b)















