# TODO 1: Add two parameters (length_ft and width_ft)
def calc_square_meters_from_feet():
    
    
    # TODO 2: Modify the code below:
    metric_area = 0
    
    
    
    

    # Leave the line below as it is
    return metric_area
